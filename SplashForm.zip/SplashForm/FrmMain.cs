﻿using System;
using System.Collections.Generic; // necessaria per List<>
using System.Diagnostics;  // per la classe Process
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace DemoControlli_4D2
{
    public partial class FrmMain : Form
    {
        // dichiara una lista di stringhe
        List<string> listaComuni;

        // dichiariamo un vettore di liste (ogni elemento del vettore è la lista delle frazioni del relativo comune dato dall'indice del vettore)
        List<string>[] listeFrazioni;

        //riferimento alla finestra secondaria
        FrmColori finestracolori ;
       
        private void InizializzaListe()
        {
            // creo e riempio la lista del comuni
            listaComuni = new List<string>();
            listaComuni.Add("Valdagno");
            listaComuni.Add("Cornedo Vicentino");
            listaComuni.Add("Castelgomberto");

            // creo e riempio l'array, con le rispettive liste, delle frazioni
            listeFrazioni = new List<string>[listaComuni.Count];

            listeFrazioni[0] = new List<string>() { "Piana", "Centro", "Massignani", "Novale", "Castelvecchio", "Ponte dei Nori" };

            listeFrazioni[1] = new List<string>() { "Cereda", "Spagnago", "Muzzolon" };

            listeFrazioni[2] = new List<string>() { "Valle", "Monte Schiavi" };
        }

        FrmSplash splash;

        // metodo "costruttore"
        public FrmMain()
        {
            InitializeComponent();
            tmrOrologio.Enabled = true; // attiva il timer

            InizializzaListe();

            // utilizziamo la lista dei comuni per aggiungere i dati al combo box
            cmbComuneResidenza.Items.AddRange(listaComuni.ToArray());

            // in alternativa potevo fare un ciclo:
            /*
             * foreach (string comune in listaComuni)
                cmbComuneResidenza.Items.Add(comune);
            */
            splash = new FrmSplash();
            splash.Show();
            Application.DoEvents();
            Thread.Sleep(2000);
        }

        private void lklContatti_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("http://www.iisvaldagno.it");

            // in alternativa
            Process p = new Process();
            p.StartInfo.UseShellExecute = true; // è necessaria per .NET Core
            p.StartInfo.FileName = "http://www.iisvaldagno.it";
            p.Start();
        }

        private void tmrOrologio_Tick(object sender, System.EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToString("HH:mm:ss");
        }

        private void cmbComuneResidenza_SelectedIndexChanged(object sender, EventArgs e)
        {
            // quando cambia la selezione del comune, carico la list box con l'elenco delle frazioni del comune scelto

            int indiceComune = cmbComuneResidenza.SelectedIndex;

            // ripuliamo dal suo contenuto la list box
            lbxFrazioni.Items.Clear();

            // ricopiamo gli elementi della lista nella list box
            lbxFrazioni.Items.AddRange(listeFrazioni[indiceComune].ToArray());
        }

        private void btnCreaPulsanti_Click(object sender, EventArgs e)
        {

            if (finestracolori == null || finestracolori.IsDisposed)
                finestracolori = new FrmColori(this);

            finestracolori.GeneraPulsanti((int)nudNPulsanti.Value);
           
            finestracolori.Show();

        }

      

        private void nudNPulsanti_ValueChanged(object sender, EventArgs e)
        {
            if(finestracolori!=null &&! finestracolori.IsDisposed)
                finestracolori.GeneraPulsanti((int)nudNPulsanti.Value);
        }

        private void btnInf_Click(object sender, EventArgs e)
        {
            FrmAboutBox f = new FrmAboutBox();
            f.ShowDialog();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {

        }

        private void FrmMain_Shown(object sender, EventArgs e)
        {
            splash.Close(); //chiude splash quando si mostra la form main
        }
    }
}
