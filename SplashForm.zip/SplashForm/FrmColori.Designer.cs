﻿
namespace DemoControlli_4D2
{
    partial class FrmColori
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pgbAvanzamento = new System.Windows.Forms.ProgressBar();
            this.flpPulsanti = new System.Windows.Forms.FlowLayoutPanel();
            this.SuspendLayout();
            // 
            // pgbAvanzamento
            // 
            this.pgbAvanzamento.Location = new System.Drawing.Point(92, 415);
            this.pgbAvanzamento.Name = "pgbAvanzamento";
            this.pgbAvanzamento.Size = new System.Drawing.Size(330, 23);
            this.pgbAvanzamento.Step = 1;
            this.pgbAvanzamento.TabIndex = 7;
            this.pgbAvanzamento.Click += new System.EventHandler(this.pgbAvanzamento_Click);
            // 
            // flpPulsanti
            // 
            this.flpPulsanti.BackColor = System.Drawing.Color.Black;
            this.flpPulsanti.Location = new System.Drawing.Point(92, 79);
            this.flpPulsanti.Name = "flpPulsanti";
            this.flpPulsanti.Size = new System.Drawing.Size(330, 330);
            this.flpPulsanti.TabIndex = 6;
            this.flpPulsanti.Paint += new System.Windows.Forms.PaintEventHandler(this.flpPulsanti_Paint);
            // 
            // FrmColori
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(513, 521);
            this.Controls.Add(this.pgbAvanzamento);
            this.Controls.Add(this.flpPulsanti);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FrmColori";
            this.Text = "FrmColori";
            this.Load += new System.EventHandler(this.FrmColori_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ProgressBar pgbAvanzamento;
        private System.Windows.Forms.FlowLayoutPanel flpPulsanti;
    }
}