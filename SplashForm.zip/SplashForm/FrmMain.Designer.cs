﻿
namespace DemoControlli_4D2
{
    partial class FrmMain
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlStatusBar = new System.Windows.Forms.Panel();
            this.lblTime = new System.Windows.Forms.Label();
            this.lklContatti = new System.Windows.Forms.LinkLabel();
            this.pnlPulsanti = new System.Windows.Forms.Panel();
            this.btnInf = new System.Windows.Forms.Button();
            this.btnCreaPulsanti = new System.Windows.Forms.Button();
            this.nudNPulsanti = new System.Windows.Forms.NumericUpDown();
            this.lblNPulsanti = new System.Windows.Forms.Label();
            this.lblInfo = new System.Windows.Forms.Label();
            this.gbxStatoCivile = new System.Windows.Forms.GroupBox();
            this.lbxFrazioni = new System.Windows.Forms.ListBox();
            this.lblFrazione = new System.Windows.Forms.Label();
            this.cmbComuneResidenza = new System.Windows.Forms.ComboBox();
            this.lblComuneResidenza = new System.Windows.Forms.Label();
            this.cbxCondizioni = new System.Windows.Forms.CheckBox();
            this.gbxStato = new System.Windows.Forms.GroupBox();
            this.rdbConiugato = new System.Windows.Forms.RadioButton();
            this.rdbCelibe = new System.Windows.Forms.RadioButton();
            this.gbxSesso = new System.Windows.Forms.GroupBox();
            this.rdbX = new System.Windows.Forms.RadioButton();
            this.rdbF = new System.Windows.Forms.RadioButton();
            this.rdbM = new System.Windows.Forms.RadioButton();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.txtCognome = new System.Windows.Forms.TextBox();
            this.lblCognome = new System.Windows.Forms.Label();
            this.tmrOrologio = new System.Windows.Forms.Timer(this.components);
            this.pnlStatusBar.SuspendLayout();
            this.pnlPulsanti.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNPulsanti)).BeginInit();
            this.gbxStatoCivile.SuspendLayout();
            this.gbxStato.SuspendLayout();
            this.gbxSesso.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlStatusBar
            // 
            this.pnlStatusBar.BackColor = System.Drawing.Color.PaleTurquoise;
            this.pnlStatusBar.Controls.Add(this.lblTime);
            this.pnlStatusBar.Controls.Add(this.lklContatti);
            this.pnlStatusBar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlStatusBar.Location = new System.Drawing.Point(0, 580);
            this.pnlStatusBar.Name = "pnlStatusBar";
            this.pnlStatusBar.Size = new System.Drawing.Size(784, 35);
            this.pnlStatusBar.TabIndex = 2;
            // 
            // lblTime
            // 
            this.lblTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTime.Location = new System.Drawing.Point(692, 8);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(80, 18);
            this.lblTime.TabIndex = 1;
            this.lblTime.Text = "00:00:00";
            // 
            // lklContatti
            // 
            this.lklContatti.AutoSize = true;
            this.lklContatti.Location = new System.Drawing.Point(12, 8);
            this.lklContatti.Name = "lklContatti";
            this.lklContatti.Size = new System.Drawing.Size(299, 18);
            this.lklContatti.TabIndex = 0;
            this.lklContatti.TabStop = true;
            this.lklContatti.Text = "Visita il nostro sito per maggiori informazioni";
            this.lklContatti.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lklContatti_LinkClicked);
            // 
            // pnlPulsanti
            // 
            this.pnlPulsanti.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlPulsanti.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.pnlPulsanti.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlPulsanti.Controls.Add(this.btnInf);
            this.pnlPulsanti.Controls.Add(this.btnCreaPulsanti);
            this.pnlPulsanti.Controls.Add(this.nudNPulsanti);
            this.pnlPulsanti.Controls.Add(this.lblNPulsanti);
            this.pnlPulsanti.Controls.Add(this.lblInfo);
            this.pnlPulsanti.Location = new System.Drawing.Point(405, 12);
            this.pnlPulsanti.Name = "pnlPulsanti";
            this.pnlPulsanti.Size = new System.Drawing.Size(367, 561);
            this.pnlPulsanti.TabIndex = 5;
            // 
            // btnInf
            // 
            this.btnInf.Location = new System.Drawing.Point(140, 180);
            this.btnInf.Name = "btnInf";
            this.btnInf.Size = new System.Drawing.Size(192, 42);
            this.btnInf.TabIndex = 4;
            this.btnInf.Text = "Informazioni...";
            this.btnInf.UseVisualStyleBackColor = true;
            this.btnInf.Click += new System.EventHandler(this.btnInf_Click);
            // 
            // btnCreaPulsanti
            // 
            this.btnCreaPulsanti.Location = new System.Drawing.Point(124, 104);
            this.btnCreaPulsanti.Name = "btnCreaPulsanti";
            this.btnCreaPulsanti.Size = new System.Drawing.Size(226, 41);
            this.btnCreaPulsanti.TabIndex = 3;
            this.btnCreaPulsanti.Text = "Crea pulsanti";
            this.btnCreaPulsanti.UseVisualStyleBackColor = true;
            this.btnCreaPulsanti.Click += new System.EventHandler(this.btnCreaPulsanti_Click);
            // 
            // nudNPulsanti
            // 
            this.nudNPulsanti.Location = new System.Drawing.Point(20, 103);
            this.nudNPulsanti.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudNPulsanti.Name = "nudNPulsanti";
            this.nudNPulsanti.Size = new System.Drawing.Size(80, 24);
            this.nudNPulsanti.TabIndex = 2;
            this.nudNPulsanti.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudNPulsanti.ValueChanged += new System.EventHandler(this.nudNPulsanti_ValueChanged);
            // 
            // lblNPulsanti
            // 
            this.lblNPulsanti.AutoSize = true;
            this.lblNPulsanti.Location = new System.Drawing.Point(17, 82);
            this.lblNPulsanti.Name = "lblNPulsanti";
            this.lblNPulsanti.Size = new System.Drawing.Size(182, 18);
            this.lblNPulsanti.TabIndex = 1;
            this.lblNPulsanti.Text = "Numero pulsanti da creare";
            // 
            // lblInfo
            // 
            this.lblInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblInfo.Location = new System.Drawing.Point(17, 17);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(333, 65);
            this.lblInfo.TabIndex = 0;
            this.lblInfo.Text = "Creare una serie di pulsanti quadrati di colore diverso (casuale) in modo tale da" +
    " riempire al massimo il contenitore qui sotto\r\n";
            // 
            // gbxStatoCivile
            // 
            this.gbxStatoCivile.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbxStatoCivile.Controls.Add(this.lbxFrazioni);
            this.gbxStatoCivile.Controls.Add(this.lblFrazione);
            this.gbxStatoCivile.Controls.Add(this.cmbComuneResidenza);
            this.gbxStatoCivile.Controls.Add(this.lblComuneResidenza);
            this.gbxStatoCivile.Controls.Add(this.cbxCondizioni);
            this.gbxStatoCivile.Controls.Add(this.gbxStato);
            this.gbxStatoCivile.Controls.Add(this.gbxSesso);
            this.gbxStatoCivile.Controls.Add(this.txtNome);
            this.gbxStatoCivile.Controls.Add(this.lblNome);
            this.gbxStatoCivile.Controls.Add(this.txtCognome);
            this.gbxStatoCivile.Controls.Add(this.lblCognome);
            this.gbxStatoCivile.Location = new System.Drawing.Point(6, 12);
            this.gbxStatoCivile.Margin = new System.Windows.Forms.Padding(4);
            this.gbxStatoCivile.Name = "gbxStatoCivile";
            this.gbxStatoCivile.Padding = new System.Windows.Forms.Padding(4);
            this.gbxStatoCivile.Size = new System.Drawing.Size(392, 560);
            this.gbxStatoCivile.TabIndex = 4;
            this.gbxStatoCivile.TabStop = false;
            this.gbxStatoCivile.Text = "Controlli comuni";
            // 
            // lbxFrazioni
            // 
            this.lbxFrazioni.FormattingEnabled = true;
            this.lbxFrazioni.ItemHeight = 18;
            this.lbxFrazioni.Location = new System.Drawing.Point(22, 402);
            this.lbxFrazioni.Name = "lbxFrazioni";
            this.lbxFrazioni.Size = new System.Drawing.Size(345, 130);
            this.lbxFrazioni.TabIndex = 12;
            // 
            // lblFrazione
            // 
            this.lblFrazione.AutoSize = true;
            this.lblFrazione.Location = new System.Drawing.Point(21, 381);
            this.lblFrazione.Name = "lblFrazione";
            this.lblFrazione.Size = new System.Drawing.Size(66, 18);
            this.lblFrazione.TabIndex = 11;
            this.lblFrazione.Text = "Frazione";
            // 
            // cmbComuneResidenza
            // 
            this.cmbComuneResidenza.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbComuneResidenza.FormattingEnabled = true;
            this.cmbComuneResidenza.Location = new System.Drawing.Point(21, 342);
            this.cmbComuneResidenza.Name = "cmbComuneResidenza";
            this.cmbComuneResidenza.Size = new System.Drawing.Size(348, 26);
            this.cmbComuneResidenza.TabIndex = 10;
            this.cmbComuneResidenza.SelectedIndexChanged += new System.EventHandler(this.cmbComuneResidenza_SelectedIndexChanged);
            // 
            // lblComuneResidenza
            // 
            this.lblComuneResidenza.AutoSize = true;
            this.lblComuneResidenza.Location = new System.Drawing.Point(18, 321);
            this.lblComuneResidenza.Name = "lblComuneResidenza";
            this.lblComuneResidenza.Size = new System.Drawing.Size(148, 18);
            this.lblComuneResidenza.TabIndex = 9;
            this.lblComuneResidenza.Text = "Comune di residenza";
            // 
            // cbxCondizioni
            // 
            this.cbxCondizioni.AutoSize = true;
            this.cbxCondizioni.Location = new System.Drawing.Point(8, 286);
            this.cbxCondizioni.Name = "cbxCondizioni";
            this.cbxCondizioni.Size = new System.Drawing.Size(228, 22);
            this.cbxCondizioni.TabIndex = 8;
            this.cbxCondizioni.Text = "Accetto le condizioni di utilizzo";
            this.cbxCondizioni.UseVisualStyleBackColor = true;
            // 
            // gbxStato
            // 
            this.gbxStato.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbxStato.Controls.Add(this.rdbConiugato);
            this.gbxStato.Controls.Add(this.rdbCelibe);
            this.gbxStato.Location = new System.Drawing.Point(7, 200);
            this.gbxStato.Name = "gbxStato";
            this.gbxStato.Size = new System.Drawing.Size(362, 80);
            this.gbxStato.TabIndex = 7;
            this.gbxStato.TabStop = false;
            this.gbxStato.Text = "Stato civile";
            // 
            // rdbConiugato
            // 
            this.rdbConiugato.AutoSize = true;
            this.rdbConiugato.Location = new System.Drawing.Point(164, 38);
            this.rdbConiugato.Name = "rdbConiugato";
            this.rdbConiugato.Size = new System.Drawing.Size(114, 22);
            this.rdbConiugato.TabIndex = 1;
            this.rdbConiugato.Text = "Coniugato / a";
            this.rdbConiugato.UseVisualStyleBackColor = true;
            // 
            // rdbCelibe
            // 
            this.rdbCelibe.AutoSize = true;
            this.rdbCelibe.Checked = true;
            this.rdbCelibe.Location = new System.Drawing.Point(14, 38);
            this.rdbCelibe.Name = "rdbCelibe";
            this.rdbCelibe.Size = new System.Drawing.Size(117, 22);
            this.rdbCelibe.TabIndex = 0;
            this.rdbCelibe.TabStop = true;
            this.rdbCelibe.Text = "Celibe / nubile";
            this.rdbCelibe.UseVisualStyleBackColor = true;
            // 
            // gbxSesso
            // 
            this.gbxSesso.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbxSesso.Controls.Add(this.rdbX);
            this.gbxSesso.Controls.Add(this.rdbF);
            this.gbxSesso.Controls.Add(this.rdbM);
            this.gbxSesso.Location = new System.Drawing.Point(8, 117);
            this.gbxSesso.Name = "gbxSesso";
            this.gbxSesso.Size = new System.Drawing.Size(362, 77);
            this.gbxSesso.TabIndex = 6;
            this.gbxSesso.TabStop = false;
            this.gbxSesso.Text = "Sesso";
            // 
            // rdbX
            // 
            this.rdbX.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rdbX.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.rdbX.Location = new System.Drawing.Point(164, 37);
            this.rdbX.Name = "rdbX";
            this.rdbX.Size = new System.Drawing.Size(74, 22);
            this.rdbX.TabIndex = 2;
            this.rdbX.Text = "X";
            this.rdbX.UseVisualStyleBackColor = false;
            // 
            // rdbF
            // 
            this.rdbF.AutoSize = true;
            this.rdbF.Location = new System.Drawing.Point(91, 37);
            this.rdbF.Name = "rdbF";
            this.rdbF.Size = new System.Drawing.Size(35, 22);
            this.rdbF.TabIndex = 1;
            this.rdbF.Text = "F";
            this.rdbF.UseVisualStyleBackColor = true;
            // 
            // rdbM
            // 
            this.rdbM.AutoSize = true;
            this.rdbM.Checked = true;
            this.rdbM.Location = new System.Drawing.Point(14, 37);
            this.rdbM.Name = "rdbM";
            this.rdbM.Size = new System.Drawing.Size(39, 22);
            this.rdbM.TabIndex = 0;
            this.rdbM.TabStop = true;
            this.rdbM.Text = "M";
            this.rdbM.UseVisualStyleBackColor = true;
            // 
            // txtNome
            // 
            this.txtNome.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNome.Location = new System.Drawing.Point(99, 75);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(271, 24);
            this.txtNome.TabIndex = 5;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(18, 78);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(49, 18);
            this.lblNome.TabIndex = 4;
            this.lblNome.Text = "No&me";
            // 
            // txtCognome
            // 
            this.txtCognome.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCognome.Location = new System.Drawing.Point(98, 36);
            this.txtCognome.Name = "txtCognome";
            this.txtCognome.Size = new System.Drawing.Size(272, 24);
            this.txtCognome.TabIndex = 3;
            // 
            // lblCognome
            // 
            this.lblCognome.AutoSize = true;
            this.lblCognome.Location = new System.Drawing.Point(18, 39);
            this.lblCognome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCognome.Name = "lblCognome";
            this.lblCognome.Size = new System.Drawing.Size(74, 18);
            this.lblCognome.TabIndex = 2;
            this.lblCognome.Text = "&Cognome";
            // 
            // tmrOrologio
            // 
            this.tmrOrologio.Interval = 1000;
            this.tmrOrologio.Tick += new System.EventHandler(this.tmrOrologio_Tick);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 615);
            this.Controls.Add(this.pnlPulsanti);
            this.Controls.Add(this.gbxStatoCivile);
            this.Controls.Add(this.pnlStatusBar);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "FrmMain";
            this.Text = "Dimostrazione utilizzo controlli comuni";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.Shown += new System.EventHandler(this.FrmMain_Shown);
            this.pnlStatusBar.ResumeLayout(false);
            this.pnlStatusBar.PerformLayout();
            this.pnlPulsanti.ResumeLayout(false);
            this.pnlPulsanti.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNPulsanti)).EndInit();
            this.gbxStatoCivile.ResumeLayout(false);
            this.gbxStatoCivile.PerformLayout();
            this.gbxStato.ResumeLayout(false);
            this.gbxStato.PerformLayout();
            this.gbxSesso.ResumeLayout(false);
            this.gbxSesso.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel pnlStatusBar;
        private System.Windows.Forms.Panel pnlPulsanti;
        private System.Windows.Forms.CheckBox cbxCondizioni;
        private System.Windows.Forms.GroupBox gbxStato;
        private System.Windows.Forms.RadioButton rdbConiugato;
        private System.Windows.Forms.RadioButton rdbCelibe;
        private System.Windows.Forms.GroupBox gbxSesso;
        private System.Windows.Forms.RadioButton rdbX;
        private System.Windows.Forms.RadioButton rdbF;
        private System.Windows.Forms.RadioButton rdbM;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtCognome;
        private System.Windows.Forms.Label lblCognome;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.LinkLabel lklContatti;
        private System.Windows.Forms.ComboBox cmbComuneResidenza;
        private System.Windows.Forms.Label lblComuneResidenza;
        private System.Windows.Forms.ListBox lbxFrazioni;
        private System.Windows.Forms.Label lblFrazione;
        private System.Windows.Forms.Timer tmrOrologio;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.NumericUpDown nudNPulsanti;
        private System.Windows.Forms.Label lblNPulsanti;
        private System.Windows.Forms.Button btnCreaPulsanti;
        public System.Windows.Forms.GroupBox gbxStatoCivile;
        private System.Windows.Forms.Button btnInf;
    }
}

