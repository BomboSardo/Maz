﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoControlli_4D2
{
    public partial class FrmColori : Form
    {
        FrmMain finestraPrincipale;
        public FrmColori(FrmMain f)
        {
            InitializeComponent();
            finestraPrincipale = f;
        }

        private void FrmColori_Load(object sender, EventArgs e)
        {

        }

        private void flpPulsanti_Paint(object sender, PaintEventArgs e)
        {

        }

        public void GeneraPulsanti(int n)
        {
            flpPulsanti.Controls.Clear();
            

            pgbAvanzamento.Minimum = 1;
            pgbAvanzamento.Maximum = n;
            pgbAvanzamento.Step = 1;
            int a = Convert.ToInt32(Math.Sqrt(n));
            double num = Math.Sqrt(n);
            string s = Convert.ToString(num);
            bool cek = false;
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == ',')
                    if (s[i + 1] == '0' || s[i + 1] == '1' || s[i + 1] == '2' || s[i + 1] == '3' || s[i + 1] == '4') //oppure math.ceiling arrotonda sempre al positivo
                        cek = true;
            }

            // generatore casuale per i colori

            Random g = new Random();
            for (int i = 0; i < n; i++)
            {

                Button btn = new Button();
                if (cek == false)
                {
                    btn.Width = flpPulsanti.ClientSize.Width / a;
                    btn.Height = flpPulsanti.ClientSize.Height / a;
                }
                else
                {
                    btn.Width = flpPulsanti.ClientSize.Width / (a + 1);
                    btn.Height = flpPulsanti.ClientSize.Height / (a + 1);
                }

                btn.Text = Convert.ToString(i + 1);
                btn.FlatStyle = FlatStyle.Popup; // aspetto piatto
                btn.Margin = new Padding(0); // azzero i margini
                btn.BackColor = Color.FromArgb(g.Next(0, 256), g.Next(0, 256), g.Next(0, 256));
                btn.ForeColor = Color.White;
                btn.Click += Btn_Click; ;
                flpPulsanti.Controls.Add(btn);
                pgbAvanzamento.PerformStep();
            }
 
        }


        private void Btn_Click(object sender, EventArgs e)
        {
            // il sender è il riferimento al pulsante che è stato cliccato
            // converto il sender in quello che è realmente, cioè un pulsante
            Button b = (Button)sender;

            MessageBox.Show("Hai premuto il pulsante " + b.Text);

            finestraPrincipale.gbxStatoCivile.BackColor = b.BackColor;

            // todo: colorare i pulsanti che stanno attorno (al massimo saranno 8)
        }

        private void pgbAvanzamento_Click(object sender, EventArgs e)
        {

        }
    }
}
